# 🌐 My Web Template

Template website responsif sederhana menggunakan **HTML**, **CSS**, dan **JavaScript**.  
Cocok untuk:
- Portfolio
- Landing page
- Tugas sekolah / kuliah
- Latihan dasar web

## 📁 Struktur Folder
```
my-web-template/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── img/
```

## 🚀 Cara Menjalankan
1. Download atau clone repo:
   ```bash
   git clone https://github.com/username/my-web-template.git
   ```
2. Buka `index.html` di browser.

## 🛠️ Teknologi
- HTML5
- CSS3
- Vanilla JavaScript

## 📸 Preview
(Tambahkan screenshot di sini jika ada)

## 📝 Lisensi
MIT License.
